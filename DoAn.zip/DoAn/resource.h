#define IDI_MyIcon 1
#define IDI_WAVE1 2
#define IDI_WAVE2 3
#define IDI_WAVE3 4
#define IDI_WAVE4 5