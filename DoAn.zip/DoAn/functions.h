struct Hour {
	int hour;
	int minute;
	int second;
};
void taoMang2ChieuDong();
void xoaMang2ChieuDong();
void khoiTao(short SDong, short SCot, short SSoBom);
void veO();
void veBang();
void taoBomNgauNhien();
void xuatBom();
void xuLySuKien();

void thang();
void thua();

void veTieuDeGame();
void veTrangThaiChoiGame(short STrangThai, short SCheDo, short SIndex);
void veMenuChinh(short SIndex);
void veMenuCapDo(short SIndex);