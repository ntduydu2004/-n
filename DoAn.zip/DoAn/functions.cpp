#include "main.h"
#include "functions.h"
#include "Console.h"
using namespace std;
CauTrucBang CTBang;
CauTrucO **CTO;

short diem;
// vi tri con tro hien tai
COORD CViTriConTro;

// su dung phim
bool BSuDungPhim = false;

// Toa do x, y ve bang
short StoaDoX;
short StoaDoY;
bool ok;

// Cap nhat trang thai choi game
bool BTrangThaiChoiGame = false;

void taoMang2ChieuDong()
{
    CTO = new CauTrucO *[CTBang.SDong];
    for (int i = 0; i < CTBang.SDong; ++i)
    {
        CTO[i] = new CauTrucO[CTBang.SCot];
    }
}

void xoaMang2ChieuDong()
{
    for (int i = 0; i < CTBang.SDong; ++i)
    {
        delete[] CTO[i];
    }
    delete[] CTO;
}

void luuToaDoBang()
{
    StoaDoX = (ConsoleWidth / 2) - (CTBang.SDong);
    StoaDoY = (((ConsoleHeight - 6) - CTBang.SCot) / 2) + 6;
}

void khoiTao(short SDong, short SCot, short SSoBom)
{
    CTBang.SDong = SDong;
    CTBang.SCot = SCot;
    CTBang.SSoBom = SSoBom;
    CTBang.SSoODaMo = 0;
    CTBang.SSoCo = 0;

    taoMang2ChieuDong();
    taoBomNgauNhien();
    luuToaDoBang();
    CViTriConTro = {0, 0};
    BTrangThaiChoiGame = true;
    veBang();
    veTrangThaiChoiGame(1, 0, 0);
    // xuatBom();
}
short toaDoX(short SX) // Toa do x ve bang
{
    return (SX * 2) + StoaDoX;
}
short toaDoY(short SY) // Toa do y ve bang
{
    return SY + StoaDoY;
}
void veO(short SX, short SY, short SKieu)
{
    switch (SKieu)
    {
    case 0: // Rong mau xanh la
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 0, 15, "  ");
        break;
    case 1: // So 1 chu mau xanh duong. Tu 1 -> 8 mau trang
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 9, 15, "1 ");
        break;
    case 2: // So 2 xanh la
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 2, 15, "2 ");
        break;
    case 3: // So 3 do
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 12, 15, "3 ");
        break;
    case 4: // So 4 xanh duong dam
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 1, 15, "4 ");
        break;
    case 5: // So 5 do dam
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 4, 15, "5 ");
        break;
    case 6: // So 6 CYAN dam
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 3, 15, "6 ");
        break;
    case 7: // So 7 den
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 0, 15, "7 ");
        break;
    case 8: // So 8 hong
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 13, 15, "8 ");
        break;
    case 9: // Bom
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 0, 12, "B ");
        break;
    case 10: // 0 chan
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 0, 8, "  ");
        break;
    case 11: // 0 le
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 0, 7, "  ");
        break;
    case 12: // Theo doi con tro
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 0, 13, "  ");
        break;
    case 13: // Cam co
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 12, 14, " F");
        break;
    case 14: // cam co khong co bom => cam co sai
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 15, 6, "Fx");
        break;
    case 15: // Cam co co bom => cam co dung
        setColorBGTextXY(toaDoX(SX), toaDoY(SY), 12, 14, "B ");
        break;
    }
}
void veBang()
{
    for (int i = 0; i < CTBang.SDong; ++i)
    {
        for (int j = 0; j < CTBang.SCot; ++j)
        {
            if (CTO[i][j].BCamCo)
                veO(j, i, 13);
            else if (CTO[i][j].SBomLanCan)
                veO(j, i, CTO[i][j].SBomLanCan);
            else if (CTO[i][j].BDaMo) // O rong
                veO(j, i, 0);
            else if ((i + j) % 2) // O le
                veO(j, i, 11);
            else // O chan
                veO(j, i, 10);
            if (BSuDungPhim)
                veO(CViTriConTro.X, CViTriConTro.Y, 12);
        }
    }
}

void taoBomNgauNhien()
{
    short SSoBom = CTBang.SSoBom;
    short SI, SJ; // SI vi tri dong, SJ vi tri cot ta se random
    srand(time(NULL));
    while (SSoBom)
    {
        SI = rand() % CTBang.SDong;
        SJ = rand() % CTBang.SCot;
        if (CTO[SI][SJ].BCoBom)
            continue;

        CTO[SI][SJ].BCoBom = true;
        SSoBom--;
    }
}
void xuatBom()
{
    for (int i = 0; i < CTBang.SDong; ++i)
    {
        for (int j = 0; j < CTBang.SCot; ++j)
        {
            cout << CTO[i][j].BCoBom << " ";
        }
        cout << endl;
    }
}
void clickPhai(short SX, short SY) // Cam co
{
    if (!CTO[SX][SY].BDaMo)
    {
        if (CTO[SX][SY].BCamCo)
        {
            CTO[SX][SY].BCamCo = false;
            CTBang.SSoCo--;
        }
        else if (CTBang.SSoCo < CTBang.SSoBom)
        {
            CTO[SX][SY].BCamCo = true;
            CTBang.SSoCo++;
        }
    }
    veBang();

    deleteRow(4, 1);
    veTrangThaiChoiGame(1, 0, 0);
}
short demBomLanCan(short SX, short SY)
{
    short SDem = 0;
    for (int i = SX - 1; i <= SX + 1; ++i)
    {
        for (int j = SY - 1; j <= SY + 1; ++j)
        {
            if (i < 0 || i >= CTBang.SDong || j < 0 || j >= CTBang.SCot || (i == SX && j == SY))
                continue;

            if (CTO[i][j].BCoBom)
                ++SDem;
        }
    }
    return SDem;
}
void moO(short SX, short SY, short &diem)
{
    if (!CTO[SX][SY].BDaMo && !CTO[SX][SY].BCamCo)
    {
        CTO[SX][SY].BDaMo = true;
        if (CTO[SX][SY].BCoBom)
            thua();
        else
        {
            CTBang.SSoODaMo++;
            diem += 50;
            short SSoBomLanCan = demBomLanCan(SX, SY);
            veTrangThaiChoiGame(1, 0, 0);
            if (SSoBomLanCan > 0)
                CTO[SX][SY].SBomLanCan = SSoBomLanCan;
            else // O rong
            {
                // dung DFS/BFS duyet lan can

                // de quy
                if (SX - 1 >= 0 && SX - 1 < CTBang.SDong && SY >= 0 && SY < CTBang.SCot)
                    moO(SX - 1, SY, diem);
                if (SX >= 0 && SX < CTBang.SDong && SY - 1 >= 0 && SY - 1 < CTBang.SCot)
                    moO(SX, SY - 1, diem);
                if (SX >= 0 && SX < CTBang.SDong && SY + 1 >= 0 && SY + 1 < CTBang.SCot)
                    moO(SX, SY + 1, diem);
                if (SX + 1 >= 0 && SX + 1 < CTBang.SDong && SY >= 0 && SY < CTBang.SCot)
                    moO(SX + 1, SY, diem);
            }
        }
    }
}
bool thongKeCo()
{
    if ((CTBang.SSoODaMo + CTBang.SSoBom) == (CTBang.SDong * CTBang.SCot))
        return true;
    else
        return false;
}

void clickTrai(short SX, short SY) // mo O
{
    if (!CTO[SX][SY].BDaMo && !CTO[SX][SY].BCamCo)
    {
        moO(SX, SY, diem);
        if (BTrangThaiChoiGame)
        {
            veBang();
            if (thongKeCo())
                thang();
        }
    }
}

void thang()
{
    BTrangThaiChoiGame = false;
    xoaMang2ChieuDong(); // giai phong con tro
    STrang = 5;
    deleteRow(4, 1);
    veTrangThaiChoiGame(2, 2, 0);

    fstream myfile;
    myfile.open("score.txt", ios::in);
    short easy, medium, hard;
    myfile >> easy >> medium >> hard;
    if (dokho == 1)
    {
        if (easy < diem)
            easy = diem;
    }
    else if (dokho == 2)
    {
        if (medium < diem)
            medium = diem;
    }
    else if (dokho == 3)
    {
        if (hard < diem)
            hard = diem;
    }
    myfile.close();
    myfile.open("score.txt", ios::out);
    myfile << easy << '\n';
    myfile << medium << '\n';
    myfile << hard << '\n';
    myfile.close();
}
void thua()
{
    for (int i = 0; i < CTBang.SDong; ++i)
    {
        for (int j = 0; j < CTBang.SCot; ++j)
        {
            if (CTO[i][j].BCamCo)
            {
                if (CTO[i][j].BCoBom)
                    veO(j, i, 15); // cam co dung
                else
                    veO(j, i, 14); // cam co sai
            }
            else
            {
                if (CTO[i][j].BCoBom)
                    veO(j, i, 9);
            }
        }
    }
    BTrangThaiChoiGame = false;
    xoaMang2ChieuDong(); // giai phong con tro
    STrang = 4;
    deleteRow(4, 1);
    veTrangThaiChoiGame(3, 2, 0); // cap nhat lai trang thai thua

    fstream myfile;
    myfile.open("score.txt", ios::in);
    short easy, medium, hard;
    myfile >> easy >> medium >> hard;
    if (dokho == 1)
    {
        if (easy < diem)
            easy = diem;
    }
    else if (dokho == 2)
    {
        if (medium < diem)
            medium = diem;
    }
    else if (dokho == 3)
    {
        if (hard < diem)
            hard = diem;
    }
    myfile.close();
    myfile.open("score.txt", ios::out);
    myfile << easy << '\n';
    myfile << medium << '\n';
    myfile << hard << '\n';
    myfile.close();
}

/*
1) Trang Menu chinh
2) Trang Menu chon cap do
3) Trang choi game
4) Trang thua
5) Trang thang
6) Trang luu game
*/

void xulyPhim(KEY_EVENT_RECORD key)
{
    if (key.bKeyDown) // Co nhan phim
    {
        switch (key.wVirtualKeyCode)
        {
        case VK_UP: // Mui ten len
            switch (STrang)
            {
            case 1: // Menu chinh
                if (STongMuc == 4)
                {
                    if (SViTriChon == 0)
                        SViTriChon = STongMuc - 1;
                    else
                        SViTriChon -= 1;
                    veMenuChinh(SViTriChon);
                }
                break;
            case 2: // Menu chon cap do
                if (STongMuc == 5)
                {
                    if (SViTriChon == 0)
                        SViTriChon = STongMuc - 1;
                    else
                        SViTriChon -= 1;
                    veMenuCapDo(SViTriChon);
                }
                break;
            case 3: // Trang choi game
                if (BTrangThaiChoiGame)
                {
                    BSuDungPhim = true;
                    CViTriConTro.Y = ((CViTriConTro.Y == 0) ? CTBang.SDong - 1 : CViTriConTro.Y - 1);
                    veBang();
                }
                break;
            case 4: // Trang thua
                veTrangThaiChoiGame(3, 2, (SViTriChon == 0) ? 1 : 0);
                break;
            case 5: // Trang thang
                veTrangThaiChoiGame(2, 2, (SViTriChon == 0) ? 1 : 0);
                break;
            case 6:
                veTrangThaiChoiGame(1, 1, (SViTriChon == 0) ? 1 : 0);
                break;
            case 7:
                if (STongMuc == 2)
                {
                    if (SViTriChon == 0)
                        SViTriChon = STongMuc - 1;
                    else
                        SViTriChon -= 1;
                    veHighScore(SViTriChon);
                }
                break;
            }
            break;
        case VK_DOWN: // xuong
            switch (STrang)
            {
            case 1: // Menu chinh
                if (STongMuc == 4)
                {
                    if (SViTriChon == STongMuc - 1)
                        SViTriChon = 0;
                    else
                        SViTriChon += 1;
                    veMenuChinh(SViTriChon);
                }
                break;
            case 2: // Menu chon cap do
                if (STongMuc == 5)
                {
                    if (SViTriChon == STongMuc - 1)
                        SViTriChon = 0;
                    else
                        SViTriChon += 1;
                    veMenuCapDo(SViTriChon);
                }
                break;
            case 3: // Trang choi game
                if (BTrangThaiChoiGame)
                {
                    BSuDungPhim = true;
                    CViTriConTro.Y = ((CViTriConTro.Y == CTBang.SDong - 1) ? 0 : CViTriConTro.Y + 1);
                    veBang();
                }
                break;
            case 4: // Trang thua
                veTrangThaiChoiGame(3, 2, (SViTriChon == 0) ? 1 : 0);
                break;
            case 5: // Trang thang
                veTrangThaiChoiGame(2, 2, (SViTriChon == 0) ? 1 : 0);
                break;
            case 6:
                veTrangThaiChoiGame(1, 1, (SViTriChon == 0) ? 1 : 0);
                break;

            case 7:
                if (STongMuc == 2)
                {
                    if (SViTriChon == STongMuc - 1)
                        SViTriChon = 0;
                    else
                        SViTriChon += 1;
                    veHighScore(SViTriChon);
                }
                break;
            }
            break;
        case VK_LEFT: // trai
            if (BTrangThaiChoiGame)
            {
                BSuDungPhim = true;
                CViTriConTro.X = ((CViTriConTro.X == 0) ? CTBang.SCot - 1 : CViTriConTro.X - 1);
                veBang();
            }
            break;
        case VK_RIGHT: // phai
            if (BTrangThaiChoiGame)
            {
                BSuDungPhim = true;
                CViTriConTro.X = ((CViTriConTro.X == CTBang.SCot - 1) ? 0 : CViTriConTro.X + 1);
                veBang();
            }
            break;
        case VK_RETURN: // phim ENTER
            switch (STrang)
            {
            case 1: // Menu chinh
                if (SViTriChon == 0)
                {
                    STrang = 2;
                    deleteRow(8, 8);
                    if (ok)
                        ok = false;
                    veMenuCapDo(0);
                }
                else if (SViTriChon == 1) // High Score
                {
                    STrang = 7;
                    deleteRow(4, 10);
                    veHighScore(0);
                }
                else if (SViTriChon == 2) // Information
                {
                    if (ok == false)
                    {
                        // setColorBGTextXY(13, toaDoY(SY), 0, 15, "  ");
                        cout << endl;
                        cout << "RULE:" << endl;
                        cout << "Z to unlock block" << endl;
                        cout << "X to flag" << endl;
                        cout << "Arrow keys to move" << endl;
                        cout << "ESC to exit/save game" << endl;
                        ok = true;
                    }
                    else
                    {
                        deleteRow(11, 5);
                        ok = false;
                    }
                    veMenuChinh(0);
                }
                else
                {
                    exit(0);
                }
                break;
            case 2:                  // Menu chon cap do
                if (SViTriChon == 0) // Easy level 9x9 and 10 bombs
                {
                    STrang = 3;
                    deleteRow(4, 10);
                    khoiTao(9, 9, 10);
                    diem = 0;
                    dokho = 1;
                }
                else if (SViTriChon == 1) // Medium
                {
                    STrang = 3;
                    deleteRow(4, 10);
                    khoiTao(16, 16, 40);
                    diem = 0;
                    dokho = 2;
                }
                else if (SViTriChon == 2) // Hard
                {
                    STrang = 3;
                    deleteRow(4, 10);
                    khoiTao(24, 24, 99);
                    diem = 0;
                    dokho = 3;
                }
                else if (SViTriChon == 3) // Custom
                {
                    STrang = 3;
                    deleteRow(4, 10);
                    short dong, cot, bom;
                    cout << "IN RA SO DONG CUA MA TRAN (MAX = 30): ";
                    cin >> dong;
                    while (dong <= 0 || dong > 30)
                    {
                        cout << "THU LAI: ";
                        cin >> dong;
                    }
                    cout << "IN RA SO COT CUA MA TRAN (MAX = 30): ";
                    cin >> cot;
                    while (cot <= 0 || cot > 30)
                    {
                        cout << "THU LAI: ";
                        cin >> cot;
                    }
                    cout << "IN RA SO BOM (MAX = 500 VA SO BOM NHO HON SO O CUA MA TRAN): ";
                    cin >> bom;
                    while (bom <= 0 || bom > 500 || bom >= cot * dong)
                    {
                        cout << "THU LAI: ";
                        cin >> bom;
                    }
                    deleteRow(4, 20);
                    khoiTao(dong, cot, bom);
                    diem = 0;
                }
                else
                {
                    STrang = 1;
                    deleteRow(4, 10);
                    veMenuChinh(0);
                }
                break;
            case 4:                  // Trang thua
                if (SViTriChon == 1) // 1: nut Exit
                {
                    STrang = 1; // Tro ve menu chinh
                    deleteRow(3, ConsoleHeight - 3);
                    veMenuChinh(0);
                }
                else
                {
                    STrang = 3; // Trang choi game
                    deleteRow(3, ConsoleHeight - 3);
                    khoiTao(CTBang.SDong, CTBang.SCot, CTBang.SSoBom);
                    diem = 0;
                    deleteRow(5, 2);
                    veTrangThaiChoiGame(1, 0, 0);
                }
                break;
            case 5: // Trang thang
                if (SViTriChon == 1)
                {
                    STrang = 1; // Tro ve menu chinh
                    deleteRow(3, ConsoleHeight - 3);
                    veMenuChinh(0);
                }
                else
                {
                    STrang = 3; // Trang choi game
                    deleteRow(3, ConsoleHeight - 3);
                    khoiTao(CTBang.SDong, CTBang.SCot, CTBang.SSoBom);
                    diem = 0;
                    deleteRow(5, 2);
                    veTrangThaiChoiGame(1, 0, 0);
                }
                break;
            case 6:
                if (SViTriChon == 1)
                {
                    STrang = 1;
                    deleteRow(3, ConsoleHeight - 3);
                    veMenuChinh(0);
                }
                else
                {
                    STrang = 3;
                    deleteRow(7, 2);
                    BTrangThaiChoiGame = true;
                }
                break;
            case 7: // Trang high score
                if (SViTriChon == 1)
                {
                    STrang = 1;
                    deleteRow(4, 10);
                    veMenuChinh(0);
                }
                else
                {
                    deleteRow(4, 10);
                    short easy = 0, medium = 0, hard = 0;
                    fstream myfile;
                    myfile.open("score.txt", ios::out);
                    myfile << easy << '\n';
                    myfile << medium << '\n';
                    myfile << hard << '\n';
                    myfile.close();
                    veHighScore(1);
                }
            }
            break;
        case VK_ESCAPE: // phim ESC
            switch (STrang)
            {
            case 1: // Menu chinh
                exit(0);
                break;
            case 2:         // Menu chon cap do
                STrang = 1; // Cap nhat lai thanh Menu chinh
                deleteRow(4, 10);
                veMenuChinh(0);
                break;
            case 3: // exit trang choi game
                STrang = 6;
                // Save game
                BTrangThaiChoiGame = false;
                veTrangThaiChoiGame(1, 1, 0);

                break;
            case 4: // Trang thua
            case 5: // Trang thang
                STrang = 2;
                deleteRow(4, ConsoleHeight - 3);
                veMenuCapDo(0);
                break;
            case 6:
                STrang = 2; // Tro ve menu chinh
                deleteRow(3, ConsoleHeight - 3);
                veMenuChinh(0);
                break;
            case 7:
                STrang = 2;
                deleteRow(4, 10);
                veMenuChinh(0);
                break;
            }
        case ClickTrai: // phim Z - mo O
            if (BTrangThaiChoiGame)
            {
                clickTrai(CViTriConTro.Y, CViTriConTro.X);
            }
            break;
        case ClickPhai: // Phim X - cam Co
            if (BTrangThaiChoiGame)
            {
                clickPhai(CViTriConTro.Y, CViTriConTro.X);
            }
            break;
        }
    }
}

void xuLySuKien()
{
    while (1)
    {
        DWORD DWNumberOfEvents = 0;     // Luu lai su kien hien tai
        DWORD DWNumberOfEventsRead = 0; // Luu lai so luong su kien da duoc loc

        HANDLE HConsoleInput = GetStdHandle(STD_INPUT_HANDLE); // Thiet bi dau vao
        GetNumberOfConsoleInputEvents(HConsoleInput, &DWNumberOfEvents);

        if (DWNumberOfEvents)
        {
            INPUT_RECORD *IREventBuffer = new INPUT_RECORD[DWNumberOfEvents]; // Con tro
            ReadConsoleInput(HConsoleInput, IREventBuffer, DWNumberOfEvents, &DWNumberOfEventsRead);
            // dat cac su kien duoc luu vao con tro EventBuffer

            // Chay vong lap de doc su kien
            for (DWORD i = 0; i < DWNumberOfEvents; ++i)
            {
                if (IREventBuffer[i].EventType == KEY_EVENT) // Neu la su kien phim
                {
                    xulyPhim(IREventBuffer[i].Event.KeyEvent);
                    // IREventBuffer[i].Event.KeyEvent
                }
            }
        }
    }
}

void veTieuDeGame()
{

    for (int i = 0; i < ConsoleWidth; ++i)
    {
        printf("-");
    }
    setColorBGTextXY((ConsoleWidth / 2) - 18.5, 1, 3, 0, "NGUYEN TRONG NGHIA + NGUYEN TRINH DUY\n");
    setColor(7);
}
void veTrangThaiChoiGame(short STrangThai, short SCheDo, short SIndex)
{
    SViTriChon = SIndex;
    STongMuc = 2;

    setColorBGTextXY(1, 3, 15, 0, "MAP  : %d x %d", CTBang.SDong, CTBang.SCot);
    setColorBGTextXY(1, 4, 15, 0, "FLAG : %d", CTBang.SSoBom - CTBang.SSoCo);
    setColorBGTextXY(1, 5, 15, 0, "SCORE : %d", diem);
    setColorBGTextXY(1, 6, 15, 0, "TIME : %d", 0);

    // ve menu thang thua
    LPSTR STRTextMenuCheDo;
    if (SCheDo == 1)
    {
        STRTextMenuCheDo = "  CONTINUE  ";
        setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuCheDo) / 2), 7, 15, ((SIndex == 0) ? 2 : 0), STRTextMenuCheDo);
    }
    if (SCheDo == 2)
    {
        STRTextMenuCheDo = "  REPLAY  ";
        setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuCheDo) / 2), 7, 15, ((SIndex == 0) ? 2 : 0), STRTextMenuCheDo);
    }

    if (SCheDo >= 1)
    {
        STRTextMenuCheDo = "  EXIT  ";
        setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuCheDo) / 2), 8, 15, ((SIndex == 1) ? 2 : 0), STRTextMenuCheDo);
    }

    // Ve Trang thai
    if (STrangThai == 1) // Playing
        setColorBGTextXY(ConsoleWidth - 22, 3, 15, 0, "State: %s", "Playing");
    if (STrangThai == 2) // Playing
        setColorBGTextXY(ConsoleWidth - 22, 3, 2, 0, "State: %s", "Win    ");
    if (STrangThai == 3) // Playing
        setColorBGTextXY(ConsoleWidth - 22, 3, 4, 0, "State: %s", "Lose   ");
}
void veMenuChinh(short SIndex)
{
    // cap nhat lai vi tri dang chon va tong muc cua menu
    SViTriChon = SIndex;
    STongMuc = 4;

    // ve menu
    LPSTR STRTextMenuChinh = "  NEW GAME  ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuChinh) / 2), 7, 15, ((SIndex == 0) ? 2 : 0), STRTextMenuChinh);

    STRTextMenuChinh = "  HIGH SCORE  ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuChinh) / 2), 8, 15, ((SIndex == 1) ? 2 : 0), STRTextMenuChinh);

    STRTextMenuChinh = "  INSTRUCTION  ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuChinh) / 2), 9, 15, ((SIndex == 2) ? 2 : 0), STRTextMenuChinh);

    STRTextMenuChinh = "  EXIT  ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuChinh) / 2), 10, 15, ((SIndex == 3) ? 2 : 0), STRTextMenuChinh);
}

void veMenuCapDo(short SIndex)
{
    // cap nhat lai vi tri dang chon va tong muc cua menu
    SViTriChon = SIndex;
    STongMuc = 5;

    LPSTR STRTextMenuChinh = "  LEVELS  ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuChinh) / 2), 4, 1, 0, STRTextMenuChinh);

    // ve menu
    STRTextMenuChinh = "EASY - 9x9 & 10 bombs";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuChinh) / 2), 7, 15, ((SIndex == 0) ? 2 : 0), STRTextMenuChinh);

    STRTextMenuChinh = "MEDIUM - 16x16 & 40 bombs";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuChinh) / 2), 8, 15, ((SIndex == 1) ? 2 : 0), STRTextMenuChinh);

    STRTextMenuChinh = "HARD - 24x24 & 99 bombs";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuChinh) / 2), 9, 15, ((SIndex == 2) ? 2 : 0), STRTextMenuChinh);

    STRTextMenuChinh = "  CUSTOM  ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuChinh) / 2), 10, 15, ((SIndex == 3) ? 2 : 0), STRTextMenuChinh);

    STRTextMenuChinh = "  EXIT  ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextMenuChinh) / 2), 11, 15, ((SIndex == 4) ? 2 : 0), STRTextMenuChinh);
}

void veHighScore(short SIndex)
{
    SViTriChon = SIndex;
    STongMuc = 2;
    LPSTR STRTextDiem = "  SCORE BOARD  ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextDiem) / 2), 4, 1, 0, STRTextDiem);
    fstream myfile;
    myfile.open("score.txt", ios::in);
    short easy, medium, hard;
    myfile >> easy >> medium >> hard;
    STRTextDiem = "EASY MODE  : ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextDiem) / 2), 7, 15, 0, STRTextDiem);
    cout << easy << '\n';
    cout << '\n';
    STRTextDiem = "MEDIUM MODE: ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextDiem) / 2), 8, 15, 0, STRTextDiem);
    cout << medium << '\n';
    cout << '\n';
    STRTextDiem = "HARD MODE  : ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextDiem) / 2), 9, 15, 0, STRTextDiem);
    cout << hard << '\n';
    myfile.close();
    STongMuc = 2;
    STRTextDiem = "  CLEAR BOARD  ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextDiem) / 2), 11, 15, (SViTriChon == 0) ? 2 : 0, STRTextDiem);
    STRTextDiem = "  EXIT  ";
    setColorBGTextXY((ConsoleWidth / 2) - (strlen(STRTextDiem) / 2), 12, 15, (SViTriChon == 1) ? 2 : 0, STRTextDiem);
}