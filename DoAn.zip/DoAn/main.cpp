#include "main.h"
#include "Console.h"
#include "functions.h"

// Trang, vi tri dang chon, tong muc, dokho
short STrang, SViTriChon, STongMuc, dokho;

int main()
{
    // thay doi size console screen
    resizeConsole(ConsoleWidth, ConsoleHeight);
    //dat ten game
    SetConsoleTitle(TEXT("MineSweeper"));

    veTieuDeGame();
    Cursor(false);

    veMenuChinh(0);
    STrang = 1;
    xuLySuKien();

    //cout << "Hello world!" << endl;
    //system("pause");
    return 0;
}
// g++ main.cpp functions.cpp Console.cpp -o main
